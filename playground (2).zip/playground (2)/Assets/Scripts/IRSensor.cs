﻿using UnityEngine;
using System.Collections.Generic;

namespace MLPlayer {
	public class IRSensor : MonoBehaviour{
		public LayerMask mask;
		//public float SensorRange;
		public bool display;
		public bool ModeGroundSensor;

		public float distance;
		public string kind;

		private bool hitFlag;
		private bool isLandmark;
		public bool food;
		private float SensorRange = 3.0f;

		void FixedUpdate()
		{
			Ray ray = new Ray(transform.position, transform.forward);

			RaycastHit hit;

			if (Physics.Raycast(ray, out hit, SensorRange, mask))
			{
				distance = hit.distance;
				kind = hit.collider.tag;
				//Debug.Log("distance");
				//Debug.Log(distance);
				hitFlag = true;
				if (hit.collider.tag == "FOOD") {
					food = true;
				} else {
					food = false;
				}
				if (ModeGroundSensor)
				{
					if (hit.collider.tag == Defs.LANDMARK)
					{
						isLandmark = true;
					}
					else
					{
						isLandmark = false;
					}
				}
			}else
			{
				distance = SensorRange;
				hitFlag = false;
				kind = "None";
			}

			if (display)
			{
				Debug.DrawRay(ray.origin, ray.direction * distance, Color.red, 0, true);
			}
		}

		public int retunDist()
		{
			//return (int)((1 - distance / SensorRange) * 255);
			return (int)(5-distance);
		}
		public int returnzeroandone()
		{
			//Debug.Log(hitFlag);
			if (kind == "FOOD") 
			{
				return (int)(1);
			}
			else if (kind == "Player")
			{
				return (int)(2);
			}
			else if (kind == "AREA")
			{
				return (int)(3);
			}
			else if (kind == "wall")
			{
				return (int)(4);
			}
			else if (kind == "detector")
			{
				return (int)(5);
			}
			else if (kind == "None")
			{
				return (int)(6);
			}
			else
			{
				return(int)(7);
			}
			

		}

		public int foodtruefalse()
		{ if(food)
			{
				return (int)255;
			}
			else
			{
				return (int)0;
			}
		}


		public int returnFlag()
		{
			if (isLandmark)
			{
				return (int)255;
			}
			else
			{
				return (int)0;
			}
		}
	}
}
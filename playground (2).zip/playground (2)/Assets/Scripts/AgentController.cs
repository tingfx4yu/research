﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AgentController : MonoBehaviour {

	public List<AxleInfo> axleInfos; // the information about each individual axle
	public float maxMotorTorque; // maximum torque the motor can apply to wheel

	private MLPlayer.Agent m_agent;

	// Use this for initialization
	private void Start()
	{
		m_agent = GetComponent<MLPlayer.Agent> ();
		if (m_agent == null) {
			Debug.Log ("GetComponent<MLPlayer.Agent> () was null.");
		}
		if (axleInfos.Count != 1) {
			Debug.Log ("axle Infos != 1 is not support now.");
		}
	}

	// Update is called once per frame
	private void Update()
	{
	}

	private void FixedUpdate()
	{	
		float rightMotor = maxMotorTorque * (m_agent.action.right_Wheel+Input.GetAxis("Horizontal"));
		float leftMotor = maxMotorTorque * (m_agent.action.left_Wheel+Input.GetAxis("Vertical"));
//		float currentSpeed = m_agent.GetComponent<Rigidbody> ().velocity.magnitude;


		float TorqueNow=axleInfos[0].right_Wheel.motorTorque;
		if (TorqueNow * rightMotor < 0 || rightMotor == 0) {
			axleInfos [0].right_Wheel.motorTorque = 0;
			axleInfos [0].right_Wheel.brakeTorque = Mathf.Abs (TorqueNow-rightMotor);
		} else {
			if (Mathf.Abs (axleInfos [0].right_Wheel.rpm) < 109.0f) {
				axleInfos [0].right_Wheel.motorTorque = Mathf.Lerp (TorqueNow, rightMotor, Time.deltaTime);
			} else {
				axleInfos [0].right_Wheel.motorTorque = 0;
			}
			axleInfos [0].right_Wheel.brakeTorque = 0;
		}
		TorqueNow = axleInfos[0].left_Wheel.motorTorque;
		if (TorqueNow * leftMotor < 0 || leftMotor == 0) {
			axleInfos [0].left_Wheel.motorTorque = 0;
			axleInfos [0].left_Wheel.brakeTorque = Mathf.Abs (TorqueNow-leftMotor);
		} else {
			if (Mathf.Abs (axleInfos [0].left_Wheel.rpm) < 109.0f) {
				axleInfos [0].left_Wheel.motorTorque = Mathf.Lerp (TorqueNow, leftMotor, Time.deltaTime);
			} else {
				axleInfos [0].left_Wheel.motorTorque = 0;
			}
			axleInfos [0].left_Wheel.brakeTorque = 0;
		}
    }
}

[System.Serializable]
public class AxleInfo {
	public WheelCollider right_Wheel;
	public WheelCollider left_Wheel;
}
	

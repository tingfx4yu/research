﻿using UnityEngine;
using System.Collections.Generic;
using System.IO;
using WebSocketSharp;
using System.Threading;

namespace MLPlayer {
	public class Agent : MonoBehaviour {
		[SerializeField] List<Camera> rgbCameras;
		[SerializeField] List<Camera> depthCameras;
		[SerializeField] List<Texture2D> rgbImages;
		[SerializeField] List<Texture2D> depthImages;
		[SerializeField] List<IRSensor> irSensors;
		[SerializeField] List<IRSensor> groundSensor;
		[SerializeField] List<Compass> compassSensor;
		[SerializeField] GameObject Ring;
		[SerializeField] List<GameObject> Led;



		public Action action { set; get; }
		public State state { set; get; }

		public int line_length_pre;
		public int line_length;
		public int line_left;
		public int line_right;
		public bool line_flag;
		public bool coll;
		public int mate_pixels;
		public int mate_pixels_pre;
		public Color targetCol;
		public Color mateCol;
		public Color nestCol;
		public int nestColArea;
		public int nestColArea_pre;
		public int foodColArea;
		private Vector3 areaP;
		private Vector3 FoodP;
		private float dist;
	
		/*void OnCollisionEnter(Collision col){
			if (col.gameObject.tag == "Plane") {
				coll = true;Debug.Log ("coll=true");
			}else{coll = false;Debug.Log ("coll=false");}

		
		}*/









		public void UpdateState ()
		{

			if (state.target [0] [0] == 255) {
				targetCol = new Color (1, 1, 0, 1);//will delete this part later on
				mateCol = Color.blue;// 1 1 0 1 = yellow; color of food
				nestCol = new Color (0, 1, 1, 1);
			} else if (state.target [0] [1] == 255) {
				targetCol = new Color (1, 1, 0, 1);
				mateCol = Color.blue;
				nestCol = new Color (0, 1, 1, 1);
			}

			state.image = new byte[rgbCameras.Count][];
			for (int i=0; i<rgbCameras.Count; i++) {
				Texture2D txture = rgbImages [i];
				state.image[i] = GetCameraImage (rgbCameras[i], ref txture);
			}
//			if (depthCameras.Count != 0) {
//				state.depth = new byte[depthCameras.Count][];
//				for (int i = 0; i < depthCameras.Count; i++) {
//					Texture2D txture = depthImages [i];
//					state.depth [i] = GetCameraImage (depthCameras [i], ref txture,0);
//				}
//			}
			if (compassSensor.Count != 0) 
			{
				state.compass = new int[1][];
				state.compass [0] = new int[compassSensor.Count];
				for (int i = 0; i < compassSensor.Count; i++) {
					state.compass [0] [i] = compassSensor [i].returnAngle ();
				}
			}
			//Debug.Log(irSensors);
			if (irSensors.Count != 0)
			{
				state.ir = new int[1][];
				state.ir [0] = new int[irSensors.Count];
				//state.ir [1] = new int[irSensors.Count];
				state.ir [0][0] = irSensors[0].returnzeroandone();
				state.ir [0][1] = irSensors[0].returnzeroandone();
				state.ir [0][7] = irSensors[0].returnzeroandone();
				/* 
				for (int i = 0; i < irSensors.Count; i++)
				{
					//state.ir[0][i]=irSensors[i].retunDist();
					state.ir[0][i]=irSensors[i].returnzeroandone();
				}
				*/
				state.foodornot = new int[1][];
				state.foodornot [0] = new int[irSensors.Count];
				for (int i = 0; i < irSensors.Count; i++)
				{
					state.foodornot[0][i]=irSensors[i].foodtruefalse();
				}
			
			}
			if (groundSensor.Count != 0)
			{
				state.ground = new int[1][];
				state.ground [0] = new int[groundSensor.Count];
				for (int i = 0; i < groundSensor.Count; i++)
				{
					state.ground[0][i] = groundSensor [i].returnFlag ();
				}
			}
		


			//example
			
			if (irSensors[0].kind =="FOOD")
			{
				//Debug.Log("detect");
				state.reward [0]+= 0;
			}
			else if (irSensors[0].kind=="wall")
			{
				state.reward [0] -= 0.1f;
			}
			else if (irSensors[0].kind=="Player")
			{
				state.reward [0] -= 0.1f;
			}
            
		}
		
		public void ResetState ()
		{
			state.Reset ();
		}

		public void StartEpisode ()
		{
			state.reward = new float[11];
			line_length_pre = 0;
			mate_pixels_pre = 0;
			nestColArea_pre = 0;
		}

		public void EndEpisode ()
		{
			state.endEpisode = true;
		}

		public void Start() {
			action = new Action ();
			state = new State ();

			rgbImages = new List<Texture2D> (rgbCameras.Capacity);
			foreach (var cam in rgbCameras) {
				rgbImages.Add (new Texture2D (cam.targetTexture.width, cam.targetTexture.height,
					TextureFormat.RGB24, false));
			}
			depthImages = new List<Texture2D> (rgbCameras.Capacity);
			foreach (var cam in depthCameras) {
				depthImages.Add(new Texture2D (cam.targetTexture.width, cam.targetTexture.height,
					TextureFormat.RGB24, false));
			}
			foreach (var cam in depthCameras) {
				cam.depthTextureMode = DepthTextureMode.Depth;
				cam.SetReplacementShader (Shader.Find ("Custom/ReplacementShader"), "");
			}

			line_length_pre = 0;
			mate_pixels_pre = 0;
			nestColArea_pre = 0;
		}

		public void SetCameraTag(int i){
			foreach (var cam in rgbCameras) {
				cam.tag = i.ToString (); 
			}
		}
		public void Distance(){
			areaP = GameObject.FindGameObjectWithTag("AREA").transform.position;
			FoodP = GameObject.FindGameObjectWithTag("FOOD").transform.position;
			dist = (areaP - FoodP).magnitude;
			if (dist <= 10f){
				state.reward [0] += 0.1f * (10f - dist);
				state.reward [1] += 0.1f * (10f - dist);
			}
			else if (dist >= 5f){
				state.reward [0] += 0.1f * (13f - dist);
				state.reward [1] += 0.1f * (13f - dist);
			}
			
			
		}

		public byte[] GetCameraImage(Camera cam, ref Texture2D tex) {
			RenderTexture currentRT = RenderTexture.active;
			RenderTexture.active = cam.targetTexture;
			cam.Render();
			tex.ReadPixels(new Rect(0, 0, cam.targetTexture.width, cam.targetTexture.height), 0, 0);
			tex.Apply();
			RenderTexture.active = currentRT;

			state.reward [0] = 0;
			line_length = 0;
			mate_pixels = 0;
			foodColArea = 0;
			nestColArea = 0;
			for (int y = 0; y < 128; y++) {
				line_left = 0;
				line_right = 0;
				line_flag = false;
				for (int x = 0; x < 128; x++) {
					var col = tex.GetPixel (x, y);
					if (col == targetCol) {//target col=yellow,mate col=blue
						if (!line_flag) {
							line_left = x;
							line_flag = true;

						}
						foodColArea += 1;
						line_right = x;
						//Debug.Log ("y");

					} else if (col == mateCol) {
						mate_pixels += 1;
						//Debug.Log ("b");
					} else if (col == nestCol) {
						nestColArea += 1;
						//Debug.Log ("g");
					}
				}
				if (line_length < (line_right - line_left)) {
					line_length = line_right - line_left;
//					tex.SetPixel (line_right,y, Color.red);
				}
			}
			/*if(line_length >0){//if food is insight
				state.reward [0] += 1;
				state.reward [1] += 1;
			}
			if (line_length > line_length_pre) {//if getting closer to food
				state.reward [0] += 2;
				state.reward [2] += 1;
			}*/
			line_length_pre = line_length;
//
			/*if (mate_pixels > 0) {//if mates are detected
				state.reward [0] += 0.5f;
				state.reward [3] += 1;
			}// will remove this part later on
			if (mate_pixels > mate_pixels_pre) {//if getting closer to mate
				state.reward [0] += 1;
				state.reward [4] += 1;
			}
			mate_pixels_pre = mate_pixels;*/

			if ((foodColArea > 7373) && (nestColArea > 0)) {
				if (nestColArea > nestColArea_pre) {
					state.reward [0] += 2.5f;
					state.reward [1] += 2.5f;
					
				}
				//45% of screen, if food occupy and get closer to nest color
				state.reward [0] += 1.5f;
				state.reward [1] += 1.5f;
			}

			if ((foodColArea > 5734) && (nestColArea > 0)) {
				if (nestColArea > nestColArea_pre) {
					state.reward [0] += 2f;
					state.reward [1] += 2f;
				}//35% of screem, if food occupy scree size and get closer to nest
				state.reward [0] += 1f;
				state.reward [1] += 1f;
			}
			nestColArea_pre = nestColArea;
			if ((foodColArea > 7373) && (nestColArea == 0)) {//45% of screen
				//state.reward [0] -= 2;
				//state.reward [1] -= 2f;
			}

			if ((foodColArea > 5734) && (nestColArea == 0)) {//35% of screem
				//state.reward [0] -= 1;
				//state.reward [1] -= 1f;
			}





			return tex.EncodeToPNG ();

			/*if (coll) {
				Debug.Log ("PLANE TOUCH");
			}else{Debug.Log ("Nothing yet");}*/



		}

		public void SetTarget(int LandmarkCount, bool initial_flag,int i){
			if (initial_flag) {
				state.target = new int[1][];
				state.target [0] = new int[2];
				state.target[0][i] = 255;
			} else {
				switch(state.target[0][0]) {
				case 0:
					state.target [0][0] = 255;
					state.target [0][1] = 0;
					break;
				case 255:
					state.target [0][0] = 0;
					state.target [0][1] = 255;
					break;
				}
			}

			switch(state.target[0][0]){
			case 0:
				Ring.GetComponent<Renderer> ().material.color = new Color (0, 1, 1, 1);
				if (Led.Count == 4) {
					Led [0].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
					Led [1].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
					Led [2].GetComponent<Renderer> ().material.color = Color.blue;
					Led [3].GetComponent<Renderer> ().material.color = Color.blue;
				}
				break;
			case 255:
				Ring.GetComponent<Renderer> ().material.color = new Color (1, 1, 0, 1);
				if (Led.Count == 4) {					
					Led [0].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
					Led [1].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
					Led [2].GetComponent<Renderer> ().material.color = Color.red;
					Led [3].GetComponent<Renderer> ().material.color = Color.red;
				}
				break;
			}
		}

		public int TargetInfo(){
			if (state.target [0][0] == 255) {
				return (int)0;
			} else if (state.target[0][1] == 255) {
				return (int)0;//modified this value from 1 to 0
			} else {
				return (int)1234;
			}
		}
	}
}

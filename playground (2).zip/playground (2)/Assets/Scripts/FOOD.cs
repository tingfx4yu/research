﻿using UnityEngine;
using System.Collections.Generic;
using System.Threading;
using MsgPack;

namespace MLPlayer
{
public class FOOD : MonoBehaviour {

		public Renderer rend;
		public Collider coll;
		public Rigidbody rb;
		private Vector3 origin;
		private	Vector3 position;
		private float distFromOrigin;
		private System.IO.StreamWriter sw;
	// Use this for initialization
	void Start () {
			rend = GetComponent<Renderer> ();
			coll = GetComponent<Collider> ();
			rb = GetComponent<Rigidbody>();
			rend.enabled = true;
			coll.enabled = true;


	}
	public void disableRendAndColl(){
			rend.enabled = false;
			coll.enabled = false;
			rb.constraints = RigidbodyConstraints.FreezeAll;

		}

	public void enableRendandColl(){
			rend.enabled = true;
			coll.enabled = true;
			rb.constraints = RigidbodyConstraints.None;

		}

	public void randomposition_horizontal(float x){
		var something= Vector3.zero;
		something.x=x;
		something.y=this.transform.position.y;
		something.z=this.transform.position.z;
		this.transform.position = something;
		sw = new System.IO.StreamWriter (Application.dataPath + "/log/position.txt", true);
			sw.Write ("{0},{1},{2}\n", something.x,something.y,something.z);
			sw.Close ();

	}
	
	public void randomposition_vertical(float z){
		var something= Vector3.zero;
		something.x=this.transform.position.x;
		something.y=this.transform.position.y;
		something.z=z;
		this.transform.position=something;
		sw = new System.IO.StreamWriter (Application.dataPath + "/log/position.txt", true);
			sw.Write ("{0},{1},{2}\n", something.x,something.y,something.z);
			sw.Close ();
	}
	

	// Update is called once per frame
	void Update () {
			origin = GameObject.FindGameObjectWithTag("AREA").transform.position;
			position = gameObject.transform.position - origin;
			position.y = 0;
			//position.z = 0;
			distFromOrigin = position.magnitude;
			if (distFromOrigin < 5) {
				disableRendAndColl ();

			
			} else {
				enableRendandColl ();
			}
	
	}
}
}
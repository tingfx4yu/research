using UnityEngine;
using System.Collections.Generic;
using System.Threading;
using MsgPack;

namespace MLPlayer
{
	public class Landmark : MonoBehaviour
	{
		public List<string> LookingCameras;

		public void Start(){
			LookingCameras = new List<string>();
		}
		void Update() {
			LookingCameras.Clear ();
		}
		void FixedUpdate(){
		}
		private void OnWillRenderObject(){
			if (Camera.current.tag != "MainCamera") {
				LookingCameras.Add (Camera.current.tag);
			}
		}
	}

}
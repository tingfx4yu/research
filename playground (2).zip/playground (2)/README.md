
Unity Sample Project
=============

## Settings

menu bar, 

+ File -> turn on "Run in Background"

for git,

+ Edit -> Project Setting -> Editor -> turn "Virsion Control" to "Visible meta file"
+ Edit -> Project Setting -> Editor -> turn "Asset Serialization" to "Force text"